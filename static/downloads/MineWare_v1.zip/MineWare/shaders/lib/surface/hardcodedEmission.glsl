vec3 RGB2HSV(vec3 c){
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));

    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

float GetHardcodedEmission(vec3 albedo, vec3 hsv) {
    #if EMISSIVE_HARDCODED == 0
    float saturatedEmission = clamp(hsv.y * 3.125 - 0.125, 0.0, 1.0) * pow(hsv.z, 4.0);
    float desaturatedEmission = clamp(hsv.z * 7.0 - 6.0, 0.0, 1.0);
    float emission = max(saturatedEmission, desaturatedEmission) * 0.5;
    #else
    float emission = pow(max(max(albedo.r, albedo.g), albedo.b), 4.0) * 0.4;
    #endif

    return emission;
}

// Complementary Unbound-style ore glow:
// Detects the actual ore pixel by its color channels, not the surrounding stone.
// Only the gem/metal part of the ore texture glows — stone parts stay dark.
float GetOreEmission(vec3 albedo, vec3 hsv, float ore, float netherOre) {
    if (ore + netherOre < 0.5) return 0.0;

    float r = albedo.r, g = albedo.g, b = albedo.b;
    float emission = 0.0;

    if (netherOre > 0.5) {
        // Nether Gold Ore — yellow/gold pixels on netherrack
        if (g - b > 0.15) emission = g * 1.5;
        // Nether Quartz Ore — bright white/light pixels
        if (g == b && r > 0.5) emission = max(emission, b * b * 2.56);
    } else {
        // Diamond Ore — blue dominant pixels
        if (b / max(r, 0.001) > 1.5 || b > 0.8)
            emission = g + 1.5;

        // Emerald Ore — green dominant, high color difference
        else if (g - r > 0.2 && g - b > 0.1)
            emission = 2.0;

        // Lapis Ore — blue much higher than red
        else if (b - r > 0.2)
            emission = 2.0;

        // Redstone Ore — red dominant
        else if (r - g > 0.2 && r - b > 0.2 && r > 0.4)
            emission = r * 2.0;

        // Gold Ore — red+green high, blue low (yellow)
        else if (g - b > 0.15 && r > 0.5)
            emission = r + 1.0;

        // Iron Ore — warm orange/brown pixels
        else if (r - b > 0.15 && r > g * 0.9)
            emission = pow(r, 1.5) * 1.5;

        // Copper Ore — orange-red with low blue
        else if (max(r * 0.5, g) - b > 0.05 && r > 0.4)
            emission = r * 2.0 + 0.7;
    }

    return emission;
}
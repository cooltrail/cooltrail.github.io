#version 120

varying vec2 texcoord;
varying vec4 glcolor;

uniform sampler2D texture;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.01) discard;
    gl_FragData[0] = color;
}

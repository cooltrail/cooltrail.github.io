#!/usr/bin/env python3
"""Install a custom Roblox skybox on macOS.

Windows move.bat copies six cache files into rbx-storage. This Mac client
stores those same assets in ~/Library/Roblox/rbx-storage.db, so the .bat
files are never read. This script writes those cache entries into the
database and copies the sky textures into Roblox and AppleBlox.

Quit Roblox before running. Launch the next game from AppleBlox.

Usage:
  python3 ~/Desktop/install_sky_mac.py "/path/to/skybox folder"

The folder must contain sky512_bk.tex, sky512_dn.tex, sky512_ft.tex,
sky512_lf.tex, sky512_rt.tex, and sky512_up.tex.
"""

import base64
import datetime
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys

SKY_IDS = [
    "a564ec8aeef3614e788d02f0090089d8",
    "7328622d2d509b95dd4dd2c721d1ca8b",
    "a50f6563c50ca4d5dcb255ee5cfab097",
    "6c94b9385e52d221f0538aadaceead2d",
    "9244e00ff9fd6cee0bb40a262bb35d31",
    "78cb2e93aee0cdbd79b15a866bc93a54",
]
FACES = ["bk", "dn", "ft", "lf", "rt", "up"]

HOME = os.path.expanduser("~")
DB_PATH = os.path.join(HOME, "Library/Roblox/rbx-storage.db")
DISK_ROOT = os.path.join(HOME, "Library/Roblox/rbx-storage")
TEMPLATE = os.path.join(
    HOME,
    "Downloads/Ruptic/skyboxfix/skyboxfix/assets",
    SKY_IDS[0],
)
APP_SKY = (
    "/Applications/Roblox.app/Contents/Resources/"
    "PlatformContent/pc/textures/sky"
)
MODS_ROOT = os.path.join(HOME, "Library/Application Support/AppleBlox/mods")
MOD_NAME = "Custom Sky"
MODS_JSON = os.path.join(
    HOME, "Library/Application Support/AppleBlox/config/mods.json"
)
BACKUP_DIR = os.path.join(HOME, "Library/Roblox/sky-cache-backup")
ORIGINAL_SKY = os.path.join(HOME, "Library/Application Support/SkySwitcher/original-sky")
STOCK_CANDIDATES = [
    os.path.join(HOME, "Desktop/roblox_skyboxes"),
    os.path.join(HOME, "Library/Roblox/sky-backup-stock"),
    ORIGINAL_SKY,
]

OLD_DATE = b"Fri, 13 Dec 2024 23:03:48 GMT"
TEMPLATE_B64 = (
    "UkJYSAIAAAA2AAAAaHR0cHM6Ly9jMC5yYnhjZG4uY29tLzRkYTJmZmMyZTZkNzBiMGJhMTk1NmYxNGMzZDZmNTNm"
    "AMgAAAADAwAAr3LVTeUAAABaZumlAwAAAHgtYW16LWlkLTI6IDNzVnkyTjloTkFMV2FjNG1Bc0xpUTc1UnM2WjZG"
    "MFBRMnN2WWl4djdRamFBWEcwdkZBTGtva0M4N2NvZktYZFcyMzlhKy9tRXVyRT0NCngtYW16LXJlcXVlc3QtaWQ6"
    "IDU4SkgxR0VNSkNCNVRNNUINCngtYW16LXJlcGxpY2F0aW9uLXN0YXR1czogQ09NUExFVEVEDQpMYXN0LU1vZGlm"
    "aWVkOiBUaHUsIDI1IEp1bCAyMDI0IDIxOjU3OjUyIEdNVA0KRVRhZzogIjRkYTJmZmMyZTZkNzBiMGJhMTk1NmYx"
    "NGMzZDZmNTNmIg0KeC1hbXotc2VydmVyLXNpZGUtZW5jcnlwdGlvbjogQUVTMjU2DQpDb250ZW50LUVuY29kaW5n"
    "OiBnemlwDQp4LWFtei12ZXJzaW9uLWlkOiB0U2VseEVzbTd2VklaamxsOTk1Ty5Db2NMUDZDS3ppQg0KQWNjZXB0"
    "LVJhbmdlczogYnl0ZXMNCkNvbnRlbnQtVHlwZTogYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtDQpTZXJ2ZXI6IEFt"
    "YXpvblMzDQpDb250ZW50LUxlbmd0aDogMTQwDQpDYWNoZS1Db250cm9sOiBwdWJsaWMsIG1heC1hZ2U9MjY1MTQ3"
    "OTINCkRhdGU6IEZyaSwgMTMgRGVjIDIwMjQgMjM6MDM6NDggR01UDQpDb25uZWN0aW9uOiBrZWVwLWFsaXZlDQpW"
    "YXJ5OiBBY2NlcHQtRW5jb2RpbmcNClJieC1DZG4tUHJvdmlkZXI6IGFrDQpBY2Nlc3MtQ29udHJvbC1FeHBvc2Ut"
    "SGVhZGVyczogUmJ4LUNkbi1Qcm92aWRlcixBa2FtYWktUmVxdWVzdC1CQw0KQWNjZXNzLUNvbnRyb2wtQWxsb3ct"
    "TWV0aG9kczogR0VUDQpBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW46ICoNClRpbWluZy1BbGxvdy1PcmlnaW46"
    "ICoNCnZlcnNpb24gNC4wMQoYAAQABAAAAAIAAAACAAAAAAAAAAAAAQAyR8O+Pk2MwRRHwz70BDW/UHgnM/IENb8A"
    "AIA/AAAAAH8Af/7/////Q0fDvjxNjEFlR8M+9AQ1v1B4JzPyBDW/AAAAAAAAAAB/AH/+/////zJHwz48TYxBFEfD"
    "vvQENb9QeCcz8gQ1vwAAAAAAAIA/fwB//v////9DR8M+Pk2MwWVHw770BDW/UHgnM/IENb8AAIA/AACAP38Af/7/"
    "////AAAAAAEAAAACAAAAAAAAAAIAAAADAAAAAAAAAAIAAAA="
)


def roblox_running():
    result = subprocess.run(
        ["pgrep", "-x", "RobloxPlayer"],
        stdout=subprocess.DEVNULL,
    )
    return result.returncode == 0


def http_date(now):
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return (
        f"{days[now.weekday()]}, {now.day:02d} {months[now.month - 1]} "
        f"{now.year} {now:%H:%M:%S} GMT"
    ).encode()


def mod_sky_dir():
    disabled = os.path.join(MODS_ROOT, MOD_NAME + ".disabled")
    active = os.path.join(MODS_ROOT, MOD_NAME)
    if os.path.isdir(disabled) and not os.path.isdir(active):
        os.rename(disabled, active)
    return os.path.join(active, "PlatformContent", "pc", "textures", "sky")


def disable_mod(name):
    active = os.path.join(MODS_ROOT, name)
    if not os.path.isdir(active):
        return
    disabled = active + ".disabled"
    if os.path.isdir(disabled):
        shutil.rmtree(disabled)
    os.rename(active, disabled)


def quit_roblox():
    subprocess.run(
        ["osascript", "-e", 'tell application "Roblox" to quit'],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for _ in range(20):
        if not roblox_running():
            return
        subprocess.run(
            ["killall", "RobloxPlayer", "RobloxMenuBar", "RobloxCrashHandler"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        subprocess.run(["sleep", "0.25"])
    if roblox_running():
        raise SystemExit("Roblox is still running. Quit it, then try again.")


def load_template():
    if os.path.isfile(TEMPLATE):
        return open(TEMPLATE, "rb").read()
    return base64.b64decode(TEMPLATE_B64)


def ensure_original_backup():
    if any(os.path.isfile(os.path.join(folder, "sky512_up.tex")) for folder in STOCK_CANDIDATES):
        return
    if not os.path.isdir(APP_SKY):
        return
    os.makedirs(ORIGINAL_SKY, exist_ok=True)
    for name in os.listdir(APP_SKY):
        if name.endswith(".tex"):
            shutil.copyfile(os.path.join(APP_SKY, name), os.path.join(ORIGINAL_SKY, name))


def fresh_cache_payload():
    data = bytearray(load_template())
    if not data.startswith(b"RBXH"):
        raise SystemExit("Sky cache template is invalid.")
    start = data.find(b"Date: ")
    if start < 0:
        raise SystemExit("Cache template has no Date header")
    start += len(b"Date: ")
    current = bytes(data[start:start + len(OLD_DATE)])
    if len(current) != len(OLD_DATE) or not current.endswith(b" GMT"):
        raise SystemExit(f"Unexpected Date header: {current!r}")
    # HTTP dates are a fixed width, so the cache header length stays valid.
    stamp = http_date(datetime.datetime.now(datetime.timezone.utc))
    if len(stamp) != len(OLD_DATE):
        raise SystemExit(f"Replacement date has the wrong length: {stamp!r}")
    data[start:start + len(OLD_DATE)] = stamp
    return bytes(data)


def install_textures(sky_dir):
    missing = [f"sky512_{face}.tex" for face in FACES if not os.path.isfile(os.path.join(sky_dir, f"sky512_{face}.tex"))]
    if missing:
        raise SystemExit("Some sides are still empty. Drop a picture on the empty panels, then click Save my sky.")
    ensure_original_backup()
    disable_mod("Pink Sunrise")
    for dest_root in (APP_SKY, mod_sky_dir()):
        os.makedirs(dest_root, exist_ok=True)
        for face in FACES:
            src = os.path.join(sky_dir, f"sky512_{face}.tex")
            shutil.copyfile(src, os.path.join(dest_root, f"sky512_{face}.tex"))
            shutil.copyfile(src, os.path.join(dest_root, f"indoor512_{face}.tex"))
    if os.path.isfile(MODS_JSON):
        with open(MODS_JSON) as handle:
            config = json.load(handle)
        config.setdefault("general", {})["enabled"] = True
        with open(MODS_JSON, "w") as handle:
            json.dump(config, handle, indent=2)
            handle.write("\n")


def backup_rows(connection):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    for asset_id in SKY_IDS:
        row = connection.execute(
            "SELECT content, size FROM files WHERE id = ?",
            (bytes.fromhex(asset_id),),
        ).fetchone()
        if row is None:
            continue
        content, size = row
        meta_path = os.path.join(BACKUP_DIR, asset_id + ".size")
        if os.path.exists(meta_path):
            continue
        with open(meta_path, "w") as handle:
            handle.write(str(size))
        if content is not None:
            with open(os.path.join(BACKUP_DIR, asset_id + ".content"), "wb") as handle:
                handle.write(content)


def install_cache(payload):
    connection = sqlite3.connect(DB_PATH)
    try:
        connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        backup_rows(connection)
        for asset_id in SKY_IDS:
            key = bytes.fromhex(asset_id)
            updated = connection.execute(
                "UPDATE files SET content = ?, size = ? WHERE id = ?",
                (payload, len(payload), key),
            ).rowcount
            if updated == 0:
                connection.execute(
                    "INSERT INTO files (id, content, size, hits, atime, category, score, ttl) "
                    "VALUES (?, ?, ?, 0, 0, 10, 0, 0)",
                    (key, payload, len(payload)),
                )
            disk_path = os.path.join(DISK_ROOT, asset_id[:2], asset_id)
            if os.path.exists(disk_path):
                subprocess.run(["chflags", "nouchg", disk_path], check=False)
            os.makedirs(os.path.dirname(disk_path), exist_ok=True)
            with open(disk_path, "wb") as handle:
                handle.write(payload)
            subprocess.run(["chflags", "uchg", disk_path], check=True)
        connection.commit()
    finally:
        connection.close()


def stock_sky_dir():
    for folder in STOCK_CANDIDATES:
        if os.path.isfile(os.path.join(folder, "sky512_up.tex")):
            return folder
    raise SystemExit("Original sky backup was not found on the Desktop or in Roblox's backup folder.")


def clear_cache():
    connection = sqlite3.connect(DB_PATH)
    try:
        connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        for asset_id in SKY_IDS:
            connection.execute("DELETE FROM files WHERE id = ?", (bytes.fromhex(asset_id),))
            disk_path = os.path.join(DISK_ROOT, asset_id[:2], asset_id)
            if os.path.exists(disk_path):
                subprocess.run(["chflags", "nouchg", disk_path], check=False)
                os.remove(disk_path)
        connection.commit()
    finally:
        connection.close()


def restore_original():
    source = stock_sky_dir()
    for name in os.listdir(source):
        if not name.endswith(".tex"):
            continue
        shutil.copyfile(os.path.join(source, name), os.path.join(APP_SKY, name))
    disable_mod("Pink Sunrise")
    disable_mod(MOD_NAME)
    clear_cache()
    print(f"Restored the original sky from {source}")


def main():
    args = sys.argv[1:]
    should_quit = "--quit-roblox" in args
    restoring = "--restore" in args
    args = [arg for arg in args if arg not in ("--quit-roblox", "--restore")]
    if restoring and args:
        raise SystemExit("Usage: python3 install_sky_mac.py --restore")
    if not restoring and len(args) != 1:
        raise SystemExit(
            'Usage: python3 install_sky_mac.py "/path/to/skybox folder"\n'
            "       python3 install_sky_mac.py --restore"
        )
    if not os.path.isfile(DB_PATH):
        raise SystemExit(f"Roblox cache database not found: {DB_PATH}")
    if roblox_running():
        if not should_quit:
            raise SystemExit("Quit Roblox completely, then run this again.")
        quit_roblox()

    if restoring:
        restore_original()
        return

    sky_dir = os.path.abspath(args[0])
    if not os.path.isdir(sky_dir):
        raise SystemExit(f"Skybox folder not found: {sky_dir}")
    payload = fresh_cache_payload()
    install_textures(sky_dir)
    install_cache(payload)
    digest = hashlib.md5(payload).hexdigest()[:8]
    print(f"Installed {os.path.basename(sky_dir)}")
    print(f"Cache entries: {len(SKY_IDS)} ({len(payload)} bytes, {digest})")
    print("Open the game from AppleBlox.")


if __name__ == "__main__":
    main()
